var searchData=
[
  ['window_20reference_0',['Window reference',['../group__window.html',1,'']]]
];
